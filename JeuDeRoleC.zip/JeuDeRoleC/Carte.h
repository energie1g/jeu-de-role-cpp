#pragma once
#include<iostream>
#include<fstream>
#include "Element.h"

class Carte : public Element {

	private:
		int width = 1280;
		int height = 768;
		sf::Texture tileTexture;
		int map[50][50];
		int loadCounterX = 0, loadCounterY = 0;
		//sf::RenderWindow win;

	public:
		Carte(const std::string &f);
		void draw(sf::RenderWindow& window);
		void ajoutGuerrier();
		void ajoutObjectRamassable();
};