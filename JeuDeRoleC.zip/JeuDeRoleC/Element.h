#pragma once
#include "SFML/Graphics.hpp";
#include<string>

class Element {
	public:
		sf::RectangleShape rect;
		sf::Sprite sprite;
		sf::Text text;
};