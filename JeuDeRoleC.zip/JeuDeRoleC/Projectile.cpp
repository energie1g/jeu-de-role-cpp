#include "Projectile.h"

Projectile::Projectile() {
	rect.setSize(sf::Vector2f(32, 32));
	rect.setPosition(400, 200);
	rect.setFillColor(sf::Color::Blue);
}

void Projectile::update() {
	if (direction == 1) {
		rect.move(0, -vitesseMovement);
	}

	if (direction == 2) {
		rect.move(0, vitesseMovement);
	}

	if (direction == 3) {
		rect.move(-vitesseMovement, 0);
	}

	if (direction == 4) {
		rect.move(vitesseMovement, 0);
	}
}