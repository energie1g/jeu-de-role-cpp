<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="jeuderole" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="tileset.png" width="256" height="256"/>
 <wangsets>
  <wangset name="New Wang Set" tile="-1"/>
 </wangsets>
</tileset>
