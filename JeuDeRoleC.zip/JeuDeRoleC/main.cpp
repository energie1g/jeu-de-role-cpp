#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include "Guerrier.h"
#include "Projectile.h"
#include "Carte.h"

using namespace std;

int main()
{
	int pCnt = 0;
	sf::RenderWindow window(sf::VideoMode(1280, 768), "SFML works!");
	window.setFramerateLimit(60);
	Carte carte("assets/jeuderole.txt");

	sf::Texture image;
	if (!image.loadFromFile("assets/g11.png")) {
		return EXIT_FAILURE;
	}

	//Guerrier (1)
	class Guerrier g1;
	g1.sprite.setTexture(image);

	//Projectiles
	vector<Projectile>::const_iterator it;
	vector<Projectile> projArr;

	//Object - Projectile
	class Projectile proj1;

	while (window.isOpen()) 
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
			proj1.rect.setPosition(g1.rect.getPosition().x + g1.rect.getSize().x/2 - proj1.rect.getSize().x/2, g1.rect.getPosition().y + g1.rect.getSize().y/2 - proj1.rect.getSize().y / 2);
			proj1.direction = g1.getDirection();
			projArr.push_back(proj1);
		}

		pCnt = 0;
		for (it = projArr.begin(); it != projArr.end(); it++) {
			projArr[pCnt].update(); // Update Projectile
			window.draw(projArr[pCnt].rect);
			pCnt++;
		}

		
		carte.draw(window);
		g1.update();
		g1.updateMovement();
		window.draw(g1.sprite);
		window.display();
	}
	return 0;
};