#pragma once
#include<iostream>
#include "Element.h"

class Guerrier : public Element {
	private:
		float speedMovement = 1;
		int speed = 0;
		int degatsAttaque = 5;
		int xGValue = 9;
		int counterWalking = 0;
		int direction = 0; // 1-up / 2-down / 3-left / 4-right
		float frameCounter = 0, switchFrame = 100, frameSpeed = 500;
		sf::Clock clock;

	public:
		void update();
		void updateMovement();
		int& getDirection();
		Guerrier();
};