#include "Guerrier.h"

Guerrier::Guerrier() {
	rect.setSize(sf::Vector2f(50, 50));
	rect.setFillColor(sf::Color::White);
	sprite.setPosition(400, 200);
	sprite.setTextureRect({ 9, 6, 33, 49 });
}

void Guerrier::update() {
	sprite.setPosition(rect.getPosition());
}

void Guerrier::updateMovement() {
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
	{
		rect.move(-speedMovement, 0);
		sprite.setTextureRect({ 1 + ((38 + 19) * counterWalking), 62, 38, 43 });
		//sprite.setOrigin({ rect.getLocalBounds().width / 2, 0 });
		//sprite.setScale({ -1, 1 });
		direction = 3;
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
	{
		rect.move(speedMovement, 0);
		sprite.setTextureRect({ 11 + ((38 + 20) * counterWalking), 120, 38, 43 });
		//sprite.setOrigin({ rect.getLocalBounds().width, 0 });
		//sprite.setScale({ 1, 1 });
		direction = 4;
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
	{
		rect.move(0, -speedMovement);
		sprite.setTextureRect({ 9 + ((28 + 30) * counterWalking), 177, 28, 43 });
		direction = 1;
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
	{
		rect.move(0, speedMovement);
		sprite.setTextureRect({ 11 + ((27 + 30) * counterWalking), 6 , 30, 46 });
		direction = 2;
	}

	frameCounter += frameSpeed * clock.restart().asSeconds();
	if (frameCounter >= switchFrame) {
		frameCounter = 0;
		counterWalking++;
		if (counterWalking == 3) {
			counterWalking = 0;
		}
	}
}

int& Guerrier::getDirection() {
	return direction;
}