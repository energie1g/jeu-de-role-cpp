#include "Carte.h"

Carte::Carte(const std::string& f) {
	std::ifstream tileSet(f);
	int rowCounter = 0;
	if (tileSet.is_open()) {

		std::string tileLocation;
		tileSet >> tileLocation;
		std::cout << tileLocation << std::endl;
		tileTexture.loadFromFile(tileLocation);
		sprite.setTexture(tileTexture);
		sprite.setTextureRect({ 192, 128, 32, 32 });
		while (!tileSet.eof()) {

			int ID;
			char com;
			tileSet >> ID;
			rowCounter++;

			map[loadCounterX][loadCounterY] = ID;

			if (rowCounter == 40) {
				rowCounter = 0;
				loadCounterX = 0;
				loadCounterY++;
			}
			else {
				loadCounterX++;
			}
			tileSet.ignore();
		}
		tileSet.close();
	}
}

void Carte::draw(sf::RenderWindow& window) {
	for (int i = 0; i < 24; i++) {
		for (int j = 0; j < 40; j++) {
			sprite.setPosition(j * 32, i * 32);
			if (map[j][i] == 38) {
				sprite.setTextureRect({192, 128, 32, 32});
			}
			if (map[j][i] == 48) {
				sprite.setTextureRect({ 0, 192, 32, 32 });
			}
			if (map[j][i] == 51) {
				sprite.setTextureRect({ 96, 192, 32, 32 });
			}
			window.draw(sprite);
		}
	}
}