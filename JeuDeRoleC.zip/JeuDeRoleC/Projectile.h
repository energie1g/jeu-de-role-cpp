#pragma once
#include "Element.h"

class Projectile : public Element {
	public:
		int vitesseMovement = 10;
		int degatsAttaque = 5;
		int direction = 0; // 1-up / 2-down / 3-left / 4-right

		Projectile();
		void update();
};

